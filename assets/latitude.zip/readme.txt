Enter the complete system ID at the prompt.

e.g.: 8WG030J-D35B
program will give: jgnijfyj

This _ONLY_ works for -D35B numbers (at least afaik).

Note, that on German keyboards, y and z are switched.


After this, the service tag could change to e.g. 8WG030J-595B.


More info on http://www.webwriters.de/mbirth/riddick/misc/bios.html

-rbr
